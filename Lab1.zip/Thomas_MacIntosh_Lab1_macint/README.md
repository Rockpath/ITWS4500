Lab 1 Read Me
Thomas MacIntosh

Unfortunately due to poor time management, I was unable to put the proper time in to fully complete this lab
in terms of css and functionality. The things that are lacking include: proper error image replacement, image padding,
and just overall css improvements. Rest assured, I will make sure to put in my due diligemce for the reaining labs.

I was able to get the tweets to display 5 at a time and to my knowledge, there are no errors with that functionality.
I included the png I was trying to use for the error image.
Also put the javascript sources at the bottom as per standard.
Lab2 ReadMe
Thomas MacIntosh

Through the use of the geolocation and dark sky apis, I was able to request the users coordinates and get the current weather stats and insert them into my webpage.

Accomplished:

Successfully acquired user coordinates
Accessed Darksky Api and successfully obtained weather info
Displayed Weather Info on Webpage
Basic CSS and Functionality

Possible Improvements (What I wanted to do, but was unsuccessful/ran out of time):

Improve CSS, such as applying unique css style to each of the data elements(day, temperature, etc) or just improving the overall look
Add Animations to the data display, such as fading in the data
Incorporate the weather for the rest of the week in a functional and visibly pleasing way
Make use of images to further enhance the web app, like using sun for sunny day.
